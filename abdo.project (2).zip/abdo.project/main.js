let stars = document.getElementById('stars');
let moon = document.getElementById('moon');
let moountain 3 = document.getElementById('mountain 3');
let mountain 4 = document.getElementById('mountain 4');
let river = document.getElementById('river');
let boat1 = document.getElementById('boat1');
let  VISCA= document.querySelector('.VISCA');
Window.onscroll = function(){
let value =scrollY;
stars.style.left =value + 'px';

}